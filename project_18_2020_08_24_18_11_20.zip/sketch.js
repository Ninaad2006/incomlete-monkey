var  bananaIMG,obsatacleIMG,obstacleGroup,monkey,jungle,
    backgroundIMG,banana,monkeyIMG,obstacle,ground,foodGroup;
var Score;
function preload(){
backgroundIMG=loadImage("jungle.png");
  obstacleIMG=loadImage("stone.png");
  bananaIMG=loadImage("banana.png");
  monkeyIMG=loadImage("Monkey_01.png","Monkey_02.png","Monkey_03.png");
} 
function setup() {
  createCanvas(400, 400);
  ground=createSprite(200,380,400,10);
  
jungle=createSprite(200,200,500,500);
  jungle.addAnimation("background",backgroundIMG);
  jungle.scale=2;

  jungle.velocityX=-5;
  obstacle=createSprite(200,290);
  obstacle.addAnimation("obstacle",obstacleIMG);
  obstacle.scale=0.2;
  jungle.velocityx=-2;
foodGroup=createGroup();
  score=0
  banana=createSprite(200,200)
  banana.addAnimation("banana",bananaIMG)
  banana.scale=0.1;
  monkey=createSprite(50,280)
  monkey.addAnimation("palyer",monkeyIMG)
  monkey.scale=0.2;
  
  obstacleGroup=createGroup();
}

function draw() {
   
  jungle.veloctiyX=-2;
  if(jungle.x<0){
  jungle.x=jungle.width/2;
  }
  obstacleGroup.collide(ground)
  if(obstacleGroup.isTouching(monkey)){
     monkey.scale=0.1;
     }
  if (foodGroup.isTouching(monkey)){
  
  }

  stroke("white");
  textSize(20);
  fill("white");
  text("Score:"+Score,300,100)
 
  obstacleGroup.add(obstacle)
  foodGroup.add(banana)
  monkey.collide(ground);
drawSprites();
}
